import { Component, OnInit } from '@angular/core';
import { ClassService } from '../Services/class.service';
// import { Observable } from 'rxjs/observable';

@Component({
  selector: 'app-classes',
  templateUrl: './classes.component.html',
  styleUrls: ['./classes.component.css']
})
export class ClassesComponent implements OnInit {
  className = '';
  isActive = true;
  // classService: ClassService;
  // public Classes;
  constructor(private classService: ClassService) { }

  ngOnInit() {
    this.getClasses();
  }
  public save(event) {
    this.className = '';
  }
  public getClasses() {
    this.classService.getClasses().subscribe(
      data => {
        // this.Classes = data;
        console.log(data);
      },
      err => { console.error(err); },
      () => console.log('done loading foods')
    );
  }
}
