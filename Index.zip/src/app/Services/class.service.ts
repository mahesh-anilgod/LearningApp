import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
// import { Observable } from 'rxjs/Observable';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type': 'application/json',
    Accept: 'application/json',
    'Access-Control-Allow-Origin': '*'
})
};
@Injectable({
  providedIn: 'root'
})
export class ClassService {

  constructor(private http: HttpClient) {}

    // Uses http.get() to load data from a single API endpoint
    getClasses() {
        return this.http.get('https://script.google.com/macros/s/AKfycbw2g3f2xI-nTlfo0zefHzUzmQeUOR19Fs93gtgsxB4xnaj0mXc/exec?action=read');
    }
}
