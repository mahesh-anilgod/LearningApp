import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

@NgModule({
  declarations: [],
  imports: [
    CommonModule
  ]
})
export class ClassesModule {
  timeStamp: string;
  id: number;
  name: string;
}
